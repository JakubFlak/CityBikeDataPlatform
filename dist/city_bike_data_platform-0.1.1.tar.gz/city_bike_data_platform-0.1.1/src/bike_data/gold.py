"""Deterministic analytical Gold models built from Silver Parquet tables."""

from bisect import bisect_left
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo

import pyarrow as pa
import pyarrow.parquet as pq

GOLD_TABLES = (
    "dim_date",
    "dim_station",
    "dim_vehicle_type",
    "dim_region",
    "dim_pricing_plan",
    "dim_pricing_plan_tier",
    "fact_station_availability",
    "fact_station_vehicle_type_availability",
    "fact_free_bike_snapshot",
    "gold_system_availability",
)

TEMPORAL_JOIN_TOLERANCE = timedelta(minutes=5)
LOCAL_TIMEZONE = ZoneInfo("Europe/Warsaw")

_BASE = {
    "observed_at": pa.timestamp("us"),
    "observed_at_local": pa.timestamp("us"),
}

GOLD_SCHEMAS = {
    "dim_date": pa.schema(
        {
            "date_key": pa.int64(),
            "calendar_date": pa.date32(),
            "year": pa.int64(),
            "quarter": pa.int64(),
            "month": pa.int64(),
            "week": pa.int64(),
            "day_of_week": pa.int64(),
            "day_name": pa.string(),
            "is_weekend": pa.bool_(),
        }
    ),
    "dim_station": pa.schema(
        {
            "station_id": pa.string(),
            **_BASE,
            "name": pa.string(),
            "short_name": pa.string(),
            "lat": pa.float64(),
            "lon": pa.float64(),
            "region_id": pa.string(),
            "capacity": pa.int64(),
            "is_virtual_station": pa.bool_(),
        }
    ),
    "dim_vehicle_type": pa.schema(
        {
            "vehicle_type_id": pa.string(),
            **_BASE,
            "name": pa.string(),
            "form_factor": pa.string(),
            "propulsion_type": pa.string(),
            "rider_capacity": pa.int64(),
            "max_range_meters": pa.int64(),
            "is_ebike": pa.bool_(),
        }
    ),
    "dim_region": pa.schema({"region_id": pa.string(), **_BASE, "name": pa.string()}),
    "dim_pricing_plan": pa.schema(
        {
            "plan_id": pa.string(),
            **_BASE,
            "name": pa.string(),
            "currency": pa.string(),
            "price": pa.float64(),
            "is_taxable": pa.bool_(),
            "description": pa.string(),
        }
    ),
    "dim_pricing_plan_tier": pa.schema(
        {
            "plan_id": pa.string(),
            "tier_index": pa.int64(),
            **_BASE,
            "start": pa.int64(),
            "interval": pa.int64(),
            "rate": pa.float64(),
            "end": pa.int64(),
        }
    ),
    "fact_station_availability": pa.schema(
        {
            "station_id": pa.string(),
            **_BASE,
            "date_key": pa.int64(),
            "hour_of_day": pa.int64(),
            "region_id": pa.string(),
            "capacity": pa.int64(),
            "num_bikes_available": pa.int64(),
            "num_docks_available": pa.int64(),
            "is_installed": pa.bool_(),
            "is_renting": pa.bool_(),
            "is_returning": pa.bool_(),
            "last_reported": pa.int64(),
        }
    ),
    "fact_station_vehicle_type_availability": pa.schema(
        {
            "station_id": pa.string(),
            "vehicle_type_id": pa.string(),
            **_BASE,
            "date_key": pa.int64(),
            "hour_of_day": pa.int64(),
            "count": pa.int64(),
            "is_ebike": pa.bool_(),
        }
    ),
    "fact_free_bike_snapshot": pa.schema(
        {
            "bike_id": pa.string(),
            **_BASE,
            "date_key": pa.int64(),
            "hour_of_day": pa.int64(),
            "station_id": pa.string(),
            "vehicle_type_id": pa.string(),
            "pricing_plan_id": pa.string(),
            "lat": pa.float64(),
            "lon": pa.float64(),
            "is_reserved": pa.bool_(),
            "is_disabled": pa.bool_(),
            "current_fuel_percent": pa.float64(),
            "current_range_meters": pa.int64(),
        }
    ),
    "gold_system_availability": pa.schema(
        {
            "observed_at": pa.timestamp("us"),
            "observed_at_local": pa.timestamp("us"),
            "date_key": pa.int64(),
            "hour_of_day": pa.int64(),
            "station_count": pa.int64(),
            "empty_station_count": pa.int64(),
            "available_stations": pa.int64(),
            "available_station_bikes": pa.int64(),
            "available_station_ebikes": pa.int64(),
            "available_station_regular_bikes": pa.int64(),
            "available_free_bikes": pa.int64(),
        }
    ),
}


def transform_silver_to_gold(silver_root: Path, gold_root: Path) -> dict[str, Path]:
    """Build deterministic Gold tables from Silver table Parquet files."""
    silver = {
        name: pq.read_table(silver_root / f"{name}.parquet").to_pylist()
        for name in (
            "station_information",
            "station_status",
            "station_status_vehicle_types",
            "vehicle_types",
            "system_regions",
            "system_pricing_plans",
            "system_pricing_plan_tiers",
            "free_bike_status",
        )
    }
    station_info = _index(silver["station_information"], "station_id")
    vehicle_types = _index(silver["vehicle_types"], "vehicle_type_id")
    regions = _index(silver["system_regions"], "region_id")
    pricing_plans = _index(silver["system_pricing_plans"], "plan_id")

    station_facts = []
    for status in silver["station_status"]:
        key = _snapshot_key(status, "station_id")
        info = _required_snapshot(station_info, key, "station_information")
        if info["region_id"] is not None:
            _required_snapshot(
                regions,
                _snapshot_key(info, "region_id"),
                "system_regions",
            )
        station_facts.append(
            {
                "station_id": status["station_id"],
                "observed_at": status["observed_at"],
                **_local_time_fields(status["observed_at"]),
                "region_id": info["region_id"],
                "capacity": info["capacity"],
                "num_bikes_available": status["num_bikes_available"],
                "num_docks_available": status["num_docks_available"],
                "is_installed": status["is_installed"],
                "is_renting": status["is_renting"],
                "is_returning": status["is_returning"],
                "last_reported": status["last_reported"],
            }
        )

    vehicle_facts = []
    for row in silver["station_status_vehicle_types"]:
        vehicle = _required_snapshot(
            vehicle_types,
            _snapshot_key(row, "vehicle_type_id"),
            "vehicle_types",
        )
        vehicle_facts.append(
            {
                "station_id": row["station_id"],
                "vehicle_type_id": row["vehicle_type_id"],
                "observed_at": row["observed_at"],
                **_local_time_fields(row["observed_at"]),
                "count": row["count"],
                "is_ebike": _is_ebike(vehicle),
            }
        )

    free_bike_facts = []
    for row in silver["free_bike_status"]:
        if row["station_id"] is not None:
            _required_snapshot(
                station_info,
                _snapshot_key(row, "station_id"),
                "station_information",
            )
        _required_snapshot(
            vehicle_types,
            _snapshot_key(row, "vehicle_type_id"),
            "vehicle_types",
        )
        if row["pricing_plan_id"] is not None:
            _required_snapshot(
                pricing_plans,
                _snapshot_key(row, "pricing_plan_id"),
                "system_pricing_plans",
            )
        free_bike_facts.append(
            {
                "bike_id": row["bike_id"],
                "observed_at": row["observed_at"],
                **_local_time_fields(row["observed_at"]),
                "station_id": row["station_id"],
                "vehicle_type_id": row["vehicle_type_id"],
                "pricing_plan_id": row["pricing_plan_id"],
                "lat": row["lat"],
                "lon": row["lon"],
                "is_reserved": row["is_reserved"],
                "is_disabled": row["is_disabled"],
                "current_fuel_percent": row["current_fuel_percent"],
                "current_range_meters": row["current_range_meters"],
            }
        )

    tables = {
        "dim_date": _date_dimension(station_facts),
        "dim_station": [
            _snapshot_fields(row, GOLD_SCHEMAS["dim_station"])
            for row in silver["station_information"]
        ],
        "dim_vehicle_type": [
            {
                **_snapshot_fields(
                    row,
                    GOLD_SCHEMAS["dim_vehicle_type"],
                    excluded={"is_ebike"},
                ),
                "is_ebike": _is_ebike(row),
            }
            for row in silver["vehicle_types"]
        ],
        "dim_region": [
            _snapshot_fields(row, GOLD_SCHEMAS["dim_region"])
            for row in silver["system_regions"]
        ],
        "dim_pricing_plan": [
            _snapshot_fields(row, GOLD_SCHEMAS["dim_pricing_plan"])
            for row in silver["system_pricing_plans"]
        ],
        "dim_pricing_plan_tier": [
            _snapshot_fields(row, GOLD_SCHEMAS["dim_pricing_plan_tier"])
            for row in silver["system_pricing_plan_tiers"]
        ],
        "fact_station_availability": station_facts,
        "fact_station_vehicle_type_availability": vehicle_facts,
        "fact_free_bike_snapshot": free_bike_facts,
    }
    tables["gold_system_availability"] = _system_metrics(
        station_facts, vehicle_facts, free_bike_facts
    )

    paths = {}
    for name in GOLD_TABLES:
        rows = sorted(tables[name], key=_sort_row)
        path = gold_root / f"{name}.parquet"
        path.parent.mkdir(parents=True, exist_ok=True)
        pq.write_table(pa.Table.from_pylist(rows, schema=GOLD_SCHEMAS[name]), path)
        paths[name] = path
    return paths


def _index(
    rows: list[dict[str, Any]], identifier: str
) -> dict[Any, tuple[list[datetime], list[dict[str, Any]]]]:
    """Index snapshots by entity ID and keep their timestamps sorted."""
    rows_by_identifier: dict[Any, list[dict[str, Any]]] = {}
    seen_timestamps: dict[Any, set[datetime]] = {}

    for row in rows:
        identifier_value, observed_at = _snapshot_key(row, identifier)

        seen = seen_timestamps.setdefault(identifier_value, set())

        if observed_at in seen:
            raise ValueError(
                f"duplicate Gold dimension key: "
                f"{identifier}={(identifier_value, observed_at)}"
            )

        seen.add(observed_at)
        rows_by_identifier.setdefault(identifier_value, []).append(row)

    result = {}

    for identifier_value, candidates in rows_by_identifier.items():
        candidates.sort(key=lambda row: row["observed_at"])

        timestamps = [
            row["observed_at"]
            for row in candidates
        ]

        result[identifier_value] = (timestamps, candidates)

    return result

def _nearest_timestamp_index(
    observed_at: datetime,
    timestamps: list[datetime],
    *,
    tolerance_error: str,
    ambiguous_error: str,
) -> int:
    """Find the unique nearest timestamp in an already sorted list."""
    position = bisect_left(timestamps, observed_at)

    # In a sorted list, the nearest value can only be the immediate
    # predecessor or successor of the insertion position.
    candidate_indices = []

    if position > 0:
        candidate_indices.append(position - 1)

    if position < len(timestamps):
        candidate_indices.append(position)

    distances = [
        (index, abs(timestamps[index] - observed_at))
        for index in candidate_indices
    ]

    nearest_distance = min(
        distance
        for _, distance in distances
    )

    if nearest_distance > TEMPORAL_JOIN_TOLERANCE:
        raise ValueError(tolerance_error)

    nearest_indices = [
        index
        for index, distance in distances
        if distance == nearest_distance
    ]

    if len(nearest_indices) > 1:
        raise ValueError(ambiguous_error)

    return nearest_indices[0]


def _snapshot_key(row: dict[str, Any], identifier: str) -> tuple[Any, Any]:
    return row[identifier], row["observed_at"]


def _required_snapshot(index, key, table_name):
    indexed = index.get(key[0])

    if indexed is None:
        raise ValueError(
            f"missing temporal foreign key in {table_name}: {key}"
        )

    timestamps, candidates = indexed

    match_index = _nearest_timestamp_index(
        key[1],
        timestamps,
        tolerance_error=(
            f"temporal foreign key outside tolerance in {table_name}: {key}"
        ),
        ambiguous_error=(
            f"ambiguous temporal foreign key in {table_name}: {key}"
        ),
    )

    return candidates[match_index]



def _local_time_fields(observed_at: datetime) -> dict[str, Any]:
    if observed_at.tzinfo is None or observed_at.utcoffset() is None:
        observed_at = observed_at.replace(tzinfo=UTC)
    local = observed_at.astimezone(LOCAL_TIMEZONE).replace(tzinfo=None)
    return {
        "observed_at_local": local,
        "date_key": int(local.strftime("%Y%m%d")),
        "hour_of_day": local.hour,
    }


def _snapshot_fields(
    row: dict[str, Any], schema: pa.Schema, excluded: set[str] | None = None
) -> dict[str, Any]:
    local_fields = _local_time_fields(row["observed_at"])
    return {
        key: local_fields[key] if key in local_fields else row[key]
        for key in schema.names
        if not excluded or key not in excluded
    }


def _is_ebike(row: dict[str, Any]) -> bool:
    return str(row.get("propulsion_type") or "").lower() in {
        "electric",
        "electric_assist",
    }


def _date_dimension(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    dates = {row["observed_at_local"].date() for row in rows}
    return [
        {
            "date_key": int(day.strftime("%Y%m%d")),
            "calendar_date": day,
            "year": day.year,
            "quarter": (day.month - 1) // 3 + 1,
            "month": day.month,
            "week": day.isocalendar().week,
            "day_of_week": day.isoweekday(),
            "day_name": day.strftime("%A"),
            "is_weekend": day.isoweekday() >= 6,
        }
        for day in sorted(dates)
    ]


def _system_metrics(station_rows, vehicle_rows, free_bike_rows):
    for row in station_rows:
        row.update(_local_time_fields(row["observed_at"]))
    grouped = {}
    for row in station_rows:
        group = grouped.setdefault(row["observed_at"], [])
        group.append(row)
    ebikes = {}
    for row in vehicle_rows:
        if row["is_ebike"]:
            ebikes[row["observed_at"]] = (
                ebikes.get(row["observed_at"], 0) + row["count"]
            )
    free_bikes = {}
    system_observations = sorted(grouped)
    for row in free_bike_rows:
        if row["station_id"] is not None:
            continue
        matched_at = _nearest_observation(row["observed_at"], system_observations)
        free_bikes[matched_at] = free_bikes.get(matched_at, 0) + 1
    metrics = []
    for observed_at, rows in grouped.items():
        available_station_bikes = sum(row["num_bikes_available"] or 0 for row in rows)
        available_station_ebikes = ebikes.get(observed_at, 0)
        empty_stations = sum(row["num_bikes_available"] == 0 for row in rows)
        metrics.append(
            {
                "observed_at": observed_at,
                "observed_at_local": rows[0]["observed_at_local"],
                "date_key": rows[0]["date_key"],
                "hour_of_day": rows[0]["hour_of_day"],
                "station_count": len(rows),
                "empty_station_count": empty_stations,
                "available_stations": len(rows) - empty_stations,
                "available_station_bikes": available_station_bikes,
                "available_station_ebikes": available_station_ebikes,
                "available_station_regular_bikes": (
                    available_station_bikes - available_station_ebikes
                ),
                "available_free_bikes": free_bikes.get(observed_at, 0),
            }
        )
    return metrics


def _nearest_observation(observed_at, candidates):
    match_index = _nearest_timestamp_index(
        observed_at,
        candidates,
        tolerance_error=(
            f"free-bike observation outside system tolerance: {observed_at}"
        ),
        ambiguous_error=(
            f"ambiguous system observation for free-bike: {observed_at}"
        ),
    )

    return candidates[match_index]



def _sort_row(row):
    return tuple(
        str(row.get(key, ""))
        for key in (
            "observed_at",
            "station_id",
            "vehicle_type_id",
            "bike_id",
            "plan_id",
            "tier_index",
        )
    )
